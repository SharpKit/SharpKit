﻿using SharpKit.JavaScript;
using SharpKit.Html4;
using SharpKit.jQuery;

namespace $rootnamespace$
{
    [JsType(JsMode.Global, Filename = "res/$safeitemname$.js")]
    public class $safeitemname$ : jQueryContextBase
    {
        /// <summary>
        /// <para>Page load event, to support this event, add this script in your page html:</para>
        /// <code>
        /// &lt;script&gt;$($safeitemname$_Load);&lt;/script&gt;
        /// </code>
        /// </summary>
        static void $safeitemname$_Load()
        {
            J(document.body).append("Ready<br/>");
        }
    }
}